<script setup></script>

<template>
  <footer>
    <hr />
    <p>Primer proyecto en VUE 3</p>
  </footer>
</template>

<style scoped>
footer {
  margin-top: 30px;
  text-align: center;
  font-size: medium;
}
</style>
